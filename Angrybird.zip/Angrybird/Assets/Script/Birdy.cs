using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controller : MonoBehaviour
{
    public float intensity;
    public float maxLength;
    public float movmentSpeed;
    public Transform birdy;
    public Transform prefab;
    // Start is called before the first frame update

    private bool isMouseDown = false;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButton(0))
        {
            if(birdy == null)
            {
                birdy = Instantiate(prefab, transform.position, transform.rotation);
            }
            isMouseDown = true;

            float xPos = Input.GetAxis("Mouse X");
            float yPos = Input.GetAxis("Mouse Y");

            birdy.position += new Vector3(xPos, yPos, 0)*Time.deltaTime*movmentSpeed;

            birdy.position = transform.position+
                Vector3.ClampMagnitude(birdy.position - transform.position, maxLength);

        }else if (isMouseDown)
        {
            if (birdy == null)
            {
                return;
            }
            isMouseDown = false;
            pushBirdy();
        }

    }

    private void pushBirdy()
    {
        birdy.gameObject.AddComponent<Rigidbody2D>();

        Rigidbody2D rb = birdy.GetComponent<Rigidbody2D>();
        Vector2 dir = transform.position - birdy.position;

        rb.AddForce(dir*intensity, ForceMode2D.Impulse);

        birdy = null;
    }
}
